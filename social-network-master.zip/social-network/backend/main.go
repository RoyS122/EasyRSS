package main

import (
	// "crypto/tls"
	"fmt"
	"log"
	"net/http"
	"os"
	// "time"

	sndb "socialNetwork/Database"
	h "socialNetwork/Handlers"
	// ut "socialNetwork/Utils"
)

func main() {

	args := os.Args[1:]
	for _, arg := range args {
		if arg == "clearDB" {
			if _, err := os.Stat("./socialNetwork.db"); err == nil {
				e := os.Remove("./socialNetwork.db")
				if e != nil {
					log.Fatal(e)
				}
			}
		}
	}

	db, err := sndb.InitDB()
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()

	http.Handle("/upload/", http.StripPrefix("/upload/", http.FileServer(http.Dir("upload"))))

	http.HandleFunc("/api/login", func(w http.ResponseWriter, r *http.Request) {
		h.LoginHandler(w, r, db)
	})

	http.HandleFunc("/api/logout", h.LogoutHandler)

	http.HandleFunc("/api/signup", func(w http.ResponseWriter, r *http.Request) {
		h.SignupHandler(w, r, db)
	})

	http.HandleFunc("/api/profile/", func(w http.ResponseWriter, r *http.Request) {
		h.ProfileHandler(w, r, db)
	})

	http.HandleFunc("/api/posts", func(w http.ResponseWriter, r *http.Request) {
		h.GetPostsHandler(w, r, db)
	})

	http.HandleFunc("/api/follow/request", func(w http.ResponseWriter, r *http.Request) {
		h.FollowUserHandler(w, r, db)
	})

	http.HandleFunc("/api/follow/accept", func(w http.ResponseWriter, r *http.Request) {
		h.AcceptOrDenyFollow(w, r, db)
	})

	http.HandleFunc("/api/follow/delete", func(w http.ResponseWriter, r *http.Request) {
		h.DeleteFollower(w, r, db)
	})

	http.HandleFunc("/api/new/post/user", func(w http.ResponseWriter, r *http.Request) {
		h.CreatePostHandler(w, r, db)
	})

	http.HandleFunc("/api/groups/create", func(w http.ResponseWriter, r *http.Request) {
		h.CreateGroupHandler(w, r, db)
	})

	http.HandleFunc("/api/groups/createvent", func(w http.ResponseWriter, r *http.Request) {
		h.CreateGroupEvent(w, r, db)
	})

	http.HandleFunc("/api/session", h.SessionHandler)

	// http.HandleFunc("/", helloHandler)

	// server := &http.Server{
	// 	Addr: ":8080",
	// 	TLSConfig: &tls.Config{
	// 		MinVersion: tls.VersionTLS12,
	// 	},
	// }

	// log.Println("Starting server on https://localhost:8080")
	// err = server.ListenAndServeTLS("server.crt", "server.key")
	// if err != nil {
	// 	log.Fatalf("Failed to start server: %v", err)
	// }
	// hostname := "localhost"

	// cert, err := ut.GetSSLCert(hostname)
	// if err != nil {
	// 	log.Fatalf("Failed to get SSL certificate: %v", err)
	// }
	// fmt.Printf("Certificate for %s:\n", hostname)
	// fmt.Printf("  Issuer: %s\n", cert.Issuer)
	// fmt.Printf("  Subject: %s\n", cert.Subject)
	// fmt.Printf("  Not Before: %s\n", cert.NotBefore.Format(time.RFC3339))
	// fmt.Printf("  Not After: %s\n", cert.NotAfter.Format(time.RFC3339))
	// fmt.Printf("  Serial Number: %s\n", cert.SerialNumber)

	fmt.Println("Server running on http://localhost:8080")
	http.ListenAndServe(":8080", nil)
}

// func helloHandler(w http.ResponseWriter, r *http.Request) {
// 	fmt.Fprintf(w, "Hello, HTTPS!")
// }
