package handlers

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"net/http"
	st "socialNetwork/Structs"
	"strings"
)

func ProfileHandler(w http.ResponseWriter, r *http.Request, db *sql.DB) {

	fmt.Println("Entered Profile Handler")

	// Set CORS headers
	w.Header().Set("Access-Control-Allow-Origin", "*")
	w.Header().Set("Access-Control-Allow-Methods", "POST, GET, OPTIONS")
	w.Header().Set("Access-Control-Allow-Headers", "Content-Type")

	if r.Method == "OPTIONS" {
		w.WriteHeader(http.StatusOK)
		return
	}

	path := strings.TrimPrefix(r.URL.Path, "/api/profile/")
	if path == "" {
		http.Error(w, "Profile UUID is missing", http.StatusBadRequest)
		fmt.Println("profile UUID is missing")
		return
	}

	uuid := path

	var user st.User

	err := db.QueryRow("SELECT * FROM users WHERE uuid = ?", uuid).Scan(
		&user.Uuid,
		&user.Username,
		&user.FirstName,
		&user.LastName,
		&user.Email,
		&user.Password,
		&user.DateOfBirth,
		&user.AboutMe,
		&user.HaveImage,
		&user.AvatarUrl,
		&user.IsPublic,
	)
	if err != nil {
		if err == sql.ErrNoRows {
			http.Error(w, "Invalid user ID", http.StatusUnauthorized)
			return
		}
		http.Error(w, "Database error", http.StatusInternalServerError)
		fmt.Println(err)
		return
	}

	user.Password = ""

	if !user.IsPublic {
		user.Email = ""
		user.DateOfBirth = ""
		user.AboutMe = ""
	}

	fmt.Println(user)

	w.WriteHeader(http.StatusOK)
	json.NewEncoder(w).Encode(user)

}
