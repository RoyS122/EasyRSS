package handlers

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	st "socialNetwork/Structs"
	ut "socialNetwork/Utils"

	"github.com/google/uuid"
	"golang.org/x/crypto/bcrypt"
)

func LoginHandler(w http.ResponseWriter, r *http.Request, db *sql.DB) {
	fmt.Println("entered LoginHandler")

	// Set CORS headers
	w.Header().Set("Access-Control-Allow-Origin", "*")
	w.Header().Set("Access-Control-Allow-Methods", "POST, GET, OPTIONS")
	w.Header().Set("Access-Control-Allow-Headers", "Content-Type")

	if r.Method == "OPTIONS" {
		w.WriteHeader(http.StatusOK)
		return
	}

	if r.Method == "POST" {

		fmt.Println("Method is POST")

		// Setting response header
		w.Header().Set("Content-Type", "application/json")

		// Get login creds from front
		var loginData st.LoginData
		err := json.NewDecoder(r.Body).Decode(&loginData)
		if err != nil {
			http.Error(w, err.Error(), http.StatusBadRequest)
			return
		}

		fmt.Println("creds = ", loginData)

		// Get user
		var user st.User
		err = db.QueryRow("SELECT * FROM users WHERE email = ?", loginData.Email).Scan(
			&user.Uuid,
			&user.Username,
			&user.FirstName,
			&user.LastName,
			&user.Email,
			&user.Password,
			&user.DateOfBirth,
			&user.AboutMe,
			&user.HaveImage,
			&user.AvatarUrl,
			&user.IsPublic,
		)
		if err != nil {
			if err == sql.ErrNoRows {
				http.Error(w, "Invalid email or password", http.StatusUnauthorized)
				return
			}
			http.Error(w, "Database error", http.StatusInternalServerError)
			fmt.Println(err)
			return
		}

		fmt.Println("user found in db")

		fmt.Println(user)

		// Check password
		if checkPassword(loginData.Password, user.Password) {
			// login success
			w.WriteHeader(http.StatusOK)
			user.Password = ""
			json.NewEncoder(w).Encode(user)
			fmt.Println("Provided password is good")
		} else {
			// login fail
			http.Error(w, "Invalid email or password", http.StatusUnauthorized)
			return
		}

	} else {
		http.Error(w, "Invalid request method", http.StatusMethodNotAllowed)
		fmt.Println("Looks like method is not POST")
	}
}

func checkPassword(password, hash string) bool {
	err := bcrypt.CompareHashAndPassword([]byte(hash), []byte(password))
	return err == nil
}

func LogoutHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method == "GET" {
		// Add logout logic here

		fmt.Fprintln(w, "Logout Endpoint")
	} else {
		http.Error(w, "Invalid request method", http.StatusMethodNotAllowed)
	}
}

func SignupHandler(w http.ResponseWriter, r *http.Request, db *sql.DB) {
	fmt.Println("Signup entered")
	have_image := false

	// Set CORS headers
	w.Header().Set("Access-Control-Allow-Origin", "*")
	w.Header().Set("Access-Control-Allow-Methods", "POST, GET, OPTIONS")
	w.Header().Set("Access-Control-Allow-Headers", "Content-Type")

	if r.Method == "OPTIONS" {
		w.WriteHeader(http.StatusOK)
		return
	}

	if r.Method != "POST" {
		http.Error(w, "Unsupported method", http.StatusMethodNotAllowed)
		return
	}

	if err := r.ParseMultipartForm(10 << 20); err != nil {
		http.Error(w, "Failed to parse multipart form: "+err.Error(), http.StatusBadRequest)
		fmt.Println(err)
		return
	}

	// Text fields
	uuid := (uuid.New()).String()
	username := r.FormValue("Username")
	firstName := r.FormValue("FirstName")
	lastName := r.FormValue("LastName")
	email := r.FormValue("Email")
	dateOfBirth := r.FormValue("DateOfBirth")
	aboutMe := r.FormValue("AboutMe")
	password := r.FormValue("Password")
	is_public := true

	fmt.Println("Trying to register:")

	fmt.Println("UUID: ", uuid)
	fmt.Println(username)
	fmt.Println(firstName)
	fmt.Println(lastName)
	fmt.Println(email)
	fmt.Println(dateOfBirth)
	fmt.Println(aboutMe)
	fmt.Println(password)

	if r.FormValue("IsPublic") == "false" {
		is_public = false
	}

	fmt.Println("form: ", r.FormValue("IsPublic"))
	fmt.Println("is_public: ", is_public)

	// File field
	fmt.Println("searching for file")
	file, handler, err := r.FormFile("Avatar")
	if err != nil {
		fmt.Println(err)
	}
	if file != nil {
		have_image = true
		defer file.Close()
	}

	var filePath string
	var fileData []byte

	if have_image {
		// Save the file
		rdmFilename := ut.GenerateFilename(handler.Filename)
		filename := uuid + filepath.Ext(rdmFilename)
		filePath = filepath.Join("upload/userImg", filename)
		fileData, err = io.ReadAll(file)
		if err != nil {
			http.Error(w, "Error reading the file", http.StatusInternalServerError)
			return
		}
		fmt.Println("We Got an Image, woohoo")
	}

	fmt.Println("no image detected")

	// Hash the password
	hashedPassword, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
	if err != nil {
		http.Error(w, "Error hashing password", http.StatusInternalServerError)
		return
	}
	fmt.Println("Password hashed")

	// Insert into database
	_, err = db.Exec(`INSERT INTO users (uuid, username, first_name, last_name, email, date_of_birth, about_me, password, have_image, avatar_url, is_public)
                      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
		uuid, username, firstName, lastName, email, dateOfBirth, aboutMe, hashedPassword, have_image, filePath, is_public)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		fmt.Println(err)
		return
	}

	if have_image {
		os.WriteFile(filePath, fileData, 0666)
		fmt.Println("Image is save")
	}

	json.NewEncoder(w).Encode((map[string]string{"message": "Registration succesfull"}))
	fmt.Println("User created successfully")
}
