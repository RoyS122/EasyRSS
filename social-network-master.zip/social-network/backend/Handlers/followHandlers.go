package handlers

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"net/http"
	st "socialNetwork/Structs"
)

func FollowUserHandler(w http.ResponseWriter, r *http.Request, db *sql.DB) {

	fmt.Println("FollowUserHandler entered")

	// Set CORS headers
	w.Header().Set("Access-Control-Allow-Origin", "*")
	w.Header().Set("Access-Control-Allow-Methods", "POST, GET, OPTIONS")
	w.Header().Set("Access-Control-Allow-Headers", "Content-Type")

	if r.Method == "OPTIONS" {
		w.WriteHeader(http.StatusOK)
		return
	}

	if r.Method != "POST" {
		http.Error(w, "Unsupported method", http.StatusMethodNotAllowed)
		return
	}

	var follow st.Follow

	err := json.NewDecoder(r.Body).Decode(&follow)
	if err != nil {
		http.Error(w, "Invalid request payload", http.StatusBadRequest)
		fmt.Println("Invalid request payload:", err)
		return
	}

	fmt.Println("user_uuid:", follow.UserUUID)
	fmt.Println("followed_by:", follow.FollowedBy)
	isAccepted := false

	_, err = db.Exec(`INSERT INTO user_follower (user_uuid, followed_by, is_accepted) 
			VALUES (?, ?, ?)`, follow.UserUUID, follow.FollowedBy, isAccepted)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		fmt.Println(err)
		return
	}

	json.NewEncoder(w).Encode((map[string]string{"message": "Follow request pending"}))

}

func AcceptOrDenyFollow(w http.ResponseWriter, r *http.Request, db *sql.DB) {

	fmt.Println("AcceptOrDenyFollow entered")

	// Set CORS headers
	w.Header().Set("Access-Control-Allow-Origin", "*")
	w.Header().Set("Access-Control-Allow-Methods", "POST, GET, OPTIONS")
	w.Header().Set("Access-Control-Allow-Headers", "Content-Type")

	if r.Method == "OPTIONS" {
		w.WriteHeader(http.StatusOK)
		return
	}

	if r.Method != "POST" {
		http.Error(w, "Unsupported method", http.StatusMethodNotAllowed)
		return
	}

	var followConfirm st.FollowConfirm

	err := json.NewDecoder(r.Body).Decode(&followConfirm)
	if err != nil {
		http.Error(w, "Invalid request payload", http.StatusBadRequest)
		fmt.Println("Invalid request payload:", err)
		return
	}

	fmt.Println("follow confirm received successfuly")

	// User declined follow
	if !followConfirm.IsAccepted {
		fmt.Println(followConfirm.UserUUID, " has declined ", followConfirm.FollowedBy, "'s invite")

		_, err = db.Exec(`DELETE FROM user_follow WHERE (user_uuid = ? AND followed_by = ?) AND is_accepted = false`)
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			fmt.Println(err)
			return
		}

		json.NewEncoder(w).Encode((map[string]string{"message": "Follow declined"}))
	}

	// User accepted follow
	fmt.Println(followConfirm.UserUUID, " has accepted ", followConfirm.FollowedBy, "'s invite")

	_, err = db.Exec(`UPDATE user_follow SET is_accepted WHERE (user_uuid = ? AND followed_by = ?) AND is_accepted = false)`)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		fmt.Println(err)
		return
	}

	json.NewEncoder(w).Encode((map[string]string{"message": "Follow accepted"}))

}

func DeleteFollower(w http.ResponseWriter, r *http.Request, db *sql.DB) {

	fmt.Println("DeleteFollower entered")

	// Set CORS headers
	w.Header().Set("Access-Control-Allow-Origin", "*")
	w.Header().Set("Access-Control-Allow-Methods", "POST, GET, OPTIONS")
	w.Header().Set("Access-Control-Allow-Headers", "Content-Type")

	if r.Method == "OPTIONS" {
		w.WriteHeader(http.StatusOK)
		return
	}

	if r.Method != "POST" {
		http.Error(w, "Unsupported method", http.StatusMethodNotAllowed)
		return
	}

	var followConfirm st.FollowConfirm

	err := json.NewDecoder(r.Body).Decode(&followConfirm)
	if err != nil {
		http.Error(w, "Invalid request payload", http.StatusBadRequest)
		fmt.Println("Invalid request payload:", err)
		return
	}

	_, err = db.Exec(`DELETE FROM user_follow WHERE (user_uuid = ? AND followed_by = ?) AND is_accepted = true`)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		fmt.Println(err)
		return
	}

	json.NewEncoder(w).Encode((map[string]string{"message": "Follower deleted"}))
}
