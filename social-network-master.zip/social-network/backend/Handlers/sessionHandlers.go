package handlers

import (
	"fmt"
	"net/http"
)

func SessionHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method == "GET" {
		fmt.Fprintln(w, "Session Check Endpoint")
	} else {
		http.Error(w, "Invalid request method", http.StatusMethodNotAllowed)
	}
}
