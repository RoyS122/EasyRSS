package handlers

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	ut "socialNetwork/Utils"

	"github.com/google/uuid"
)

func CreateGroupHandler(w http.ResponseWriter, r *http.Request, db *sql.DB) {
	fmt.Println("CreateGroupHandler entered")
	have_image := false

	// Set CORS headers
	w.Header().Set("Access-Control-Allow-Origin", "*")
	w.Header().Set("Access-Control-Allow-Methods", "POST, GET, OPTIONS")
	w.Header().Set("Access-Control-Allow-Headers", "Content-Type")

	if r.Method == "OPTIONS" {
		w.WriteHeader(http.StatusOK)
		return
	}

	if r.Method != "POST" {
		http.Error(w, "Unsupported method", http.StatusMethodNotAllowed)
		return
	}

	if err := r.ParseMultipartForm(10 << 20); err != nil {
		http.Error(w, "Failed to parse multipart form: "+err.Error(), http.StatusBadRequest)
		fmt.Println(err)
		return
	}

	// Text fields for group
	uuid := (uuid.New()).String()
	name := r.FormValue("Name")
	description := r.FormValue("Description")
	creationDate := r.FormValue("CreationDate")
	createdBy := r.FormValue("CreatedBy")

	fmt.Println("Trying to create group:")

	fmt.Println("UUID: ", uuid)
	fmt.Println("name: ", name)
	fmt.Println("description: ", description)
	fmt.Println("created on: ", creationDate)
	fmt.Println("by: ", createdBy)

	// File field
	fmt.Println("searching for file")
	file, handler, err := r.FormFile("GroupImg")
	if err != nil {
		fmt.Println(err)
	}
	if file != nil {
		have_image = true
		defer file.Close()
	}

	var filePath string
	var fileData []byte

	if have_image {
		// Save the file
		rdmFilename := ut.GenerateFilename(handler.Filename)
		filename := uuid + filepath.Ext(rdmFilename)
		filePath = filepath.Join("upload/groupImg", filename)
		fileData, err = io.ReadAll(file)
		if err != nil {
			http.Error(w, "Error reading the file", http.StatusInternalServerError)
			return
		}
		fmt.Println("We Got an Image, woohoo")
	}

	fmt.Println("no image detected")

	// Insert into database
	_, err = db.Exec(`INSERT INTO groups (uuid, name, desciption, have_image, creation_date, created_by_user_uuid, group_image)
                      VALUES (?, ?, ?, ?, ?, ?, ?)`,
		uuid, name, description, have_image, creationDate, createdBy, filePath)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		fmt.Println(err)
		return
	}

	if have_image {
		os.WriteFile(filePath, fileData, 0666)
		fmt.Println("Image is save")
	}

	json.NewEncoder(w).Encode((map[string]string{"message": "Group created succesfully"}))
}
