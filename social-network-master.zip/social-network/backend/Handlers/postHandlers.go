package handlers

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	st "socialNetwork/Structs"
	ut "socialNetwork/Utils"

	"github.com/google/uuid"
)

func CreatePostHandler(w http.ResponseWriter, r *http.Request, db *sql.DB) {
	fmt.Println("CreatePost entered")
	have_image := false

	// Set CORS headers
	w.Header().Set("Access-Control-Allow-Origin", "*")
	w.Header().Set("Access-Control-Allow-Methods", "POST, GET, OPTIONS")
	w.Header().Set("Access-Control-Allow-Headers", "Content-Type")

	if r.Method == "OPTIONS" {
		w.WriteHeader(http.StatusOK)
		return
	}

	if r.Method != "POST" {
		http.Error(w, "Unsupported method", http.StatusMethodNotAllowed)
		return
	}

	if err := r.ParseMultipartForm(10 << 20); err != nil {
		http.Error(w, "Failed to parse multipart form: "+err.Error(), http.StatusBadRequest)
		fmt.Println(err)
		return
	}

	// Text fields
	uuid := (uuid.New()).String()
	userUuid := r.FormValue("UserUuid")
	content := r.FormValue("Content")
	date := r.FormValue("Date")
	postType := r.FormValue("PostType")
	groupUuid := r.FormValue("GroupUuid")

	fmt.Println("Trying to create post:")

	fmt.Println("UUID: ", uuid)
	fmt.Println(userUuid)
	fmt.Println(content)
	fmt.Println(date)
	fmt.Println(postType)
	fmt.Println(groupUuid)

	// File field
	fmt.Println("searching for file")
	file, handler, err := r.FormFile("PostImage")
	if err != nil {
		fmt.Println(err)
	}
	if file != nil {
		have_image = true
		defer file.Close()
	}

	var filePath string
	var fileData []byte

	if have_image {

		// Save the file
		rdmFilename := ut.GenerateFilename(handler.Filename)
		filename := uuid + filepath.Ext(rdmFilename)
		filePath = filepath.Join("upload/postImg", filename)
		fileData, err = io.ReadAll(file)
		if err != nil {
			http.Error(w, "Error reading the file", http.StatusInternalServerError)
			return
		}
		fmt.Println("We Got a post Image, woohoo")
	}

	fmt.Println("no image detected")

	// Insert into database
	_, err = db.Exec(`INSERT INTO posts (uuid, user_uuid, content, date, type, group_uuid, have_image, post_image)
                      VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
		uuid, userUuid, content, date, postType, groupUuid, have_image, filePath)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		fmt.Println(err)
		return
	}

	if have_image {
		os.WriteFile(filePath, fileData, 0666)
		fmt.Println("Image is save")
	}

	json.NewEncoder(w).Encode((map[string]string{"message": "Post registered"}))
	fmt.Println("Post created successfully")
}

func GetPostsHandler(w http.ResponseWriter, r *http.Request, db *sql.DB) {

	fmt.Println("entered GetPostHandler")

	// Set CORS headers
	w.Header().Set("Access-Control-Allow-Origin", "*")
	w.Header().Set("Access-Control-Allow-Methods", "POST, GET, OPTIONS")
	w.Header().Set("Access-Control-Allow-Headers", "Content-Type")

	if r.Method == "OPTIONS" {
		w.WriteHeader(http.StatusOK)
		return
	}

	// Example of handling multiple types of requests in one function
	if r.Method != "GET" {
		http.Error(w, "Invalid method", http.StatusMethodNotAllowed)
		return
	} else {

		// For private post, get uuid via URL

		// Setting response header
		w.Header().Set("Content-Type", "application/json")

		var posts []st.Post

		rows, err := db.Query("SELECT * FROM posts WHERE type = public")
		if err != nil {
			fmt.Println("Error reading post table")
			return
		}

		defer rows.Close()

		for rows.Next() {
			var post st.Post
			err := rows.Scan(&post.Uuid, &post.UserUuid, &post.Content, &post.Date, &post.Type, &post.GroupUuid, &post.HaveImage, &post.PostImage)
			if err != nil {
				http.Error(w, "Error getting posts in db", http.StatusInternalServerError)
				fmt.Println(err)
				return
			}
			posts = append(posts, post)
		}

		fmt.Println(posts)
	}
}
