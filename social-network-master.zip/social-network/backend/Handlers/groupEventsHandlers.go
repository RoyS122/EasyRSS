package handlers

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"net/http"

	"github.com/google/uuid"
)

func CreateGroupEvent(w http.ResponseWriter, r *http.Request, db *sql.DB) {

	fmt.Println("CreateGroupHandler entered")

	// Set CORS headers
	w.Header().Set("Access-Control-Allow-Origin", "*")
	w.Header().Set("Access-Control-Allow-Methods", "POST, GET, OPTIONS")
	w.Header().Set("Access-Control-Allow-Headers", "Content-Type")

	if r.Method == "OPTIONS" {
		w.WriteHeader(http.StatusOK)
		return
	}

	if r.Method != "POST" {
		http.Error(w, "Unsupported method", http.StatusMethodNotAllowed)
		return
	}

	if err := r.ParseMultipartForm(10 << 20); err != nil {
		http.Error(w, "Failed to parse multipart form: "+err.Error(), http.StatusBadRequest)
		fmt.Println(err)
		return
	}

	// Text fields for group
	uuid := (uuid.New()).String()
	name := r.FormValue("Name")
	groupUuid := r.FormValue("GroupUuid")
	description := r.FormValue("Description")
	startDate := r.FormValue("CreationDate")
	endDate := r.FormValue("CreatedBy")

	fmt.Println("Trying to create event:")

	fmt.Println("UUID: ", uuid)
	fmt.Println("name: ", name)
	fmt.Println("for group: ", groupUuid)
	fmt.Println("description: ", description)
	fmt.Println("starts on: ", startDate)
	fmt.Println("ends on: ", endDate)

	// Insert into group_event
	_, err := db.Exec(`INSERT INTO group_event (uuid, name, group_uuid, desciption, date_start, date_end)
                      VALUES (?, ?, ?, ?, ?, ?)`,
		uuid, name, groupUuid, description, startDate, endDate)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		fmt.Println(err)
		return
	}

	json.NewEncoder(w).Encode((map[string]string{"message": "Group event created succesfully"}))

}
