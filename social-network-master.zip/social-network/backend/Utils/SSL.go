package utils

import (
	"crypto/tls"
	"crypto/x509"
	"fmt"
	"net"
)

// GetSSLCert retrieves the SSL certificate of the given hostname
func GetSSLCert(hostname string) (*x509.Certificate, error) {
	// Load system CA certificates
	rootCAs, err := x509.SystemCertPool()
	if err != nil {
		return nil, fmt.Errorf("failed to load root CA certificates: %v", err)
	}

	// Create a TLS configuration with root CAs
	tlsConfig := &tls.Config{
		RootCAs: rootCAs,
	}

	conn, err := tls.Dial("tcp", net.JoinHostPort(hostname, "8443"), tlsConfig)
	if err != nil {
		return nil, err
	}
	defer conn.Close()

	if len(conn.ConnectionState().PeerCertificates) > 0 {
		return conn.ConnectionState().PeerCertificates[0], nil
	}
	return nil, fmt.Errorf("no certificates found")
}
