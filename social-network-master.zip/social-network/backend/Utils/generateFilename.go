package utils

import (
	"crypto/rand"
	"fmt"
	"log"
	"path/filepath"
)

func GenerateFilename(originalName string) string {
	b := make([]byte, 16)
	_, err := rand.Read(b)
	if err != nil {
		log.Fatal(err)
	}
	ext := filepath.Ext(originalName)
	return fmt.Sprintf("%x%s", b, ext)
}
