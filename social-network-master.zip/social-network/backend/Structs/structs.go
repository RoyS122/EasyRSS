package structs

type User struct {
	Uuid        string `JSON:"uuid"`
	Username    string `JSON:"username"`
	FirstName   string `JSON:"first_name"`
	LastName    string `JSON:"last_name"`
	Email       string `JSON:"email"`
	Password    string `JSON:"password"`
	DateOfBirth string `JSON:"date_of_birth"`
	AboutMe     string `JSON:"about_me"`
	HaveImage   bool   `JSON:"have_image"`
	Avatar      string `JSON:"avatar"`
	AvatarUrl   string `JSON:"avatar_url"`
	IsPublic    bool   `JSON:"IsPublic"`
}

type LoginData struct {
	Email    string `JSON:"email"`
	Password string `JSON:"password"`
}

type Comment struct {
	Uuid     string
	UserUuid string
	Content  string
}

type Post struct {
	Uuid      string `JSON:"uuid"`
	UserUuid  string `JSON:"user_uuid"`
	Content   string `JSON:"content"`
	Date      string `JSON:"date"`
	Type      string `JSON:"post_type"`
	GroupUuid string `JSON:"group_uuid"`
	HaveImage bool   `JSON:"avatar"`
	PostImage string `JSON:"post_image"`
}

type Follow struct {
	UserUUID   string `json:"user_uuid"`
	FollowedBy string `json:"followed_by"`
}

type FollowConfirm struct {
	UserUUID   string `json:"user_uuid"`
	FollowedBy string `json:"followed_by"`
	IsAccepted bool   `json:"is_accepted"`
}
