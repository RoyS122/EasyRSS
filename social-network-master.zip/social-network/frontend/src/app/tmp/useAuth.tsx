"use client";
import { useEffect, useState } from "react";
import { getUserByUuid } from "../service/api/user";

export const useAuth = () => {
  //const [isLogged, setIsLogged] = useState(true);
  const [isLogged, setIsLogged] = useState(false); // use this line by default the other is for force login
  const [user, setUser] = useState({
    aboutMe: "",
    dateOfBirth: "",
    email: "",
    firstName: "",
    uuid: "",
    lastName: "",
    username: "",
    haveAvatar: false,
    avatarUrl: "",
  });

  useEffect(() => {
    const fetchUser = async () => {
      const localStorageUser = localStorage.getItem("user");

      if (localStorageUser) {
        const userUuid: string = JSON.parse(localStorageUser).userData;
        const result = await getUserByUuid(userUuid);

        setUser({
          aboutMe: result.AboutMe,
          dateOfBirth: result.DateOfBirth,
          email: result.Email,
          firstName: result.FirstName,
          uuid: result.Uuid,
          lastName: result.LastName,
          username: result.Username,
          haveAvatar: result.HaveImage,
          avatarUrl: process.env.NEXT_PUBLIC_API_URL + "/" + result.AvatarUrl,
        });
        setIsLogged(true);
      }
    };

    fetchUser();
  }, []);

  return { isLogged, user };
};
