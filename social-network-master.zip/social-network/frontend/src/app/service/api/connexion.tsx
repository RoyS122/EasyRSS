interface LoginCredentials {
    email: string;
    password: string;
}

interface LoginResponse {
    Uuid: string;
    Username: string;
    FirstName: string;
    LastName: string;
    Email: string;
    DateOfBirth: string;
    AboutMe: string;
    HaveImage: boolean;
    Avatar_url: string;
}

interface RegisterCredentials {
    Username: string | null;
    FirstName: string;
    LastName: string;
    Email: string;
    Password: string;
    DateOfBirth: string;
    AboutMe: string | null;
    Avatar: File | null;
    IsPublic: boolean;
}

interface RegisterResponse {
    message: string;
}

export const login = async (credentials: LoginCredentials): Promise<LoginResponse> => {
    try {
        const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(credentials),
        });
        
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        
        const data: LoginResponse = await response.json();
        return data;
    } catch (error) {
        console.error('Login error:', error);
        throw error;
    }
};

export const registration = async (credentials: RegisterCredentials): Promise<RegisterResponse | string> => {
    try {
        const formData = new FormData();
        formData.append('Username', credentials.Username ?? '');
        formData.append('FirstName', credentials.FirstName);
        formData.append('LastName', credentials.LastName);
        formData.append('Email', credentials.Email);
        formData.append('Password', credentials.Password);
        formData.append('DateOfBirth', credentials.DateOfBirth);
        formData.append('AboutMe', credentials.AboutMe ?? '');
        formData.append('IsPublic', credentials.IsPublic.toString());
        if (credentials.Avatar) {
            formData.append('Avatar', credentials.Avatar);
        }

        const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/signup`, {
            method: 'POST',
            body: formData,
        });

        if (!response.ok) {
            throw new Error(await response.text());
        }

        const data: RegisterResponse = await response.json();
        return data;
    } catch (error) {
        console.error('Registration error:', error);
        throw error;
    }
};