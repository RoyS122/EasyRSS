interface UserPostCredentials {
    UserUuid: string;
    Content: string;
    PostType: string;
    UserList: string;
    Date: string;
    PostImage: File | null;
}

interface PostResponse {
    message: string;
}

interface GroupPostCredentials {
    UserUuid: string;
    Content: string;
    GroupUuid: string;
    Date: string;
    PostImage: File | null;
}


export const userPost = async (credentials: UserPostCredentials): Promise<PostResponse | string> => {
    try {
        const formData = new FormData();
        formData.append('UserUuid', credentials.UserUuid);
        formData.append('Content', credentials.Content);
        formData.append('PostType', credentials.PostType);
        formData.append('UserList', credentials.UserList);
        formData.append('Date', credentials.Date);
        if (credentials.PostImage) {
            formData.append('PostImage', credentials.PostImage);
        }

        const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/new/post/user`, {
            method: 'POST',
            body: formData,
        });

        if (!response.ok) {
            throw new Error(await response.text());
        }

        const data: PostResponse = await response.json();
        return data;
    } catch (error) {
        console.error('Registration error:', error);
        throw error;
    }
};

export const groupPost = async (credentials: GroupPostCredentials): Promise<PostResponse | string> => {
    try {
        const formData = new FormData();
        formData.append('UserUuid', credentials.UserUuid);
        formData.append('Content', credentials.Content);
        formData.append('GroupUuid', credentials.GroupUuid);
        formData.append('Date', credentials.Date);
        if (credentials.PostImage) {
            formData.append('PostImage', credentials.PostImage);
        }

        const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/new/post/group`, {
            method: 'POST',
            body: formData,
        });

        if (!response.ok) {
            throw new Error(await response.text());
        }

        const data: PostResponse = await response.json();
        return data;
    } catch (error) {
        console.error('Registration error:', error);
        throw error;
    }
};




// Code de Nico
// export const registration = async (credentials: RegisterCredentials): Promise<RegisterResponse> => {
//     try {
//         const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/signup`, {
//             method: 'POST',
//             headers: {
//                 'Content-Type': 'multipart/form-data',
//             },
//             body: JSON.stringify(credentials),
//         });
        
//         if (!response.ok) {
//             throw new Error('Network response was not ok');
//         }
        
//         const data: RegisterResponse = await response.json();
//         return data;
//     } catch (error) {
//         console.error('Login error:', error);
//         throw error;
//     }
// };