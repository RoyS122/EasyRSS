interface userResponse {
    Uuid: string;
    Username: string;
    FirstName: string;
    LastName: string;
    Email: string;
    DateOfBirth: string;
    AboutMe: string;
    HaveImage: boolean;
    AvatarUrl: string;
}

export const getUserByUuid = async (uuid: string): Promise<userResponse> => {
    try {
        const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/profile/${uuid}`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
            }
        });
        
        
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        
        const data: userResponse = await response.json();
        return data;
    } catch (error) {
        console.error('get User error:', error);
        throw error;
    }
};