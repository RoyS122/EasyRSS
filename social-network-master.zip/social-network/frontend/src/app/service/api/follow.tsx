interface FollowRequestCredentials {
    user_uuid: string;
    followed_by: string;
}

interface Response {
    message: string
}

export const followRequest = async (credentials: FollowRequestCredentials): Promise<Response> => {
    try {
        const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/follow/request`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(credentials),
        });
        
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        
        const data: Response = await response.json();
        return data;
    } catch (error) {
        console.error('Login error:', error);
        throw error;
    }
};