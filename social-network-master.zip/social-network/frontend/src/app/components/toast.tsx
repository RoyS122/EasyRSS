import { toast, ToastOptions } from 'react-toastify';

type ToastType = "error" | "success" | "info" | "warning";

export const showToast = (text: string, type: ToastType) => {
  const options: ToastOptions = {
    position: "top-center",
    autoClose: 5000,
    hideProgressBar: false,
    closeOnClick: true,
    pauseOnHover: true,
    draggable: true,
    progress: undefined,
  };

  toast[type](text, options);
};
