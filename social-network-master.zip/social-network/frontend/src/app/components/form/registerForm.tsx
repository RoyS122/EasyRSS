import ImageProfilInput from "../input/imageProfilPicture";
import React, { useState } from "react";
import { showToast } from "../toast";
import { registration } from '@/app/service/api/connexion';
import { useRouter } from 'next/navigation';

export default function RegisterForm() {
  const [formData, setFormData] = useState({
    aboutMe: "",
    avatar: null as File | null,
    dateOfBirth: "",
    email: "",
    firstName: "",
    lastName: "",
    password: "",
    confirmationPassword: "",
    username: "",
    is_public: true,
  });

  const router = useRouter();

  const handleChange = (e: any) => {
    const { name, value, type, checked } = e.target;
    setFormData((prevState) => ({
      ...prevState,
      [name]: type === 'checkbox' ? checked : type === 'radio' ? (value === 'true') : value,
    }));
  };

  const handleImageChange = (file: File) => {
    setFormData((prevState) => ({
      ...prevState,
      avatar: file,
    }));
  };

  const handleSubmit = async (e: any) => {
    e.preventDefault();
    console.log(formData);
    if (formData.password !== formData.confirmationPassword) {
      showToast('Passwords do not match', 'error');
      return;
    }

    try {
      console.log('Registration form data:', formData)
      const result = await registration({
        Username: formData.username,
        FirstName: formData.firstName,
        LastName: formData.lastName,
        Email: formData.email,
        Password: formData.password,
        DateOfBirth: formData.dateOfBirth,
        AboutMe: formData.aboutMe,
        Avatar: formData.avatar,
        IsPublic: formData.is_public,
      });
      
      console.log('Registration successful:', result);
      showToast('Registration successful', 'success');
      router.push('/login'); 
    }catch (error) {
      console.error('Registration failed:', error);
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      showToast(errorMessage, 'error');
    }

  };

  return (
    <div className="mt-4 sm:mx-auto sm:w-full sm:max-w-sm">
      <form className="space-y-3" method="POST"  onSubmit={handleSubmit} encType="multipart/form-data">
        <div className="grid grid-cols-2 gap-x-4">
          <div>
            <label
              htmlFor="firstName"
              className="block text-sm font-medium leading-6 text-gray-900"
            >
              <span className="font-medium text-red-600 hover:underline">*</span>
              First name
            </label>
            <input
              id="firstName"
              name="firstName"
              type="text"
              autoComplete="firstName"
              value={formData.firstName}
              onChange={handleChange}
              required
              className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6"
            />
          </div>
          <div>
            <label
              htmlFor="lastName"
              className="block text-sm font-medium leading-6 text-gray-900"
            >
              <span className="font-medium text-red-600 hover:underline">*</span>
              Last name
            </label>
            <input
              id="lastName"
              name="lastName"
              type="text"
              autoComplete="lastName"
              required
              value={formData.lastName}
              onChange={handleChange}
              className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6"
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-x-4">
          <div>
            <label
              htmlFor="username"
              className="block text-sm font-medium leading-6 text-gray-900"
            >
              Username
            </label>
            <input
              id="username"
              name="username"
              type="text"
              autoComplete="username"
              value={formData.username}
              onChange={handleChange}
              className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6"
            />
          </div>
          <div>
            <label
              htmlFor="dateOfBirth"
              className="block text-sm font-medium leading-6 text-gray-900"
            >
              <span className="font-medium text-red-600 hover:underline">*</span>
              Date of Birth
            </label>
            <input
              id="dateOfBirth"
              name="dateOfBirth"
              type="date"
              value={formData.dateOfBirth}
              onChange={handleChange}
              required
              className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6"
            />
          </div>
        </div>

        <div>
          <label
            htmlFor="email"
            className="block text-sm font-medium leading-6 text-gray-900"
          >
            <span className="font-medium text-red-600 hover:underline">*</span>
            Email address
          </label>
          <div className="mt-2">
            <input
              id="email"
              name="email"
              type="email"
              autoComplete="email"
              value={formData.email}
              onChange={handleChange}
              required
              className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6"
            />
          </div>
        </div>

        <div>
          <h3 className="block text-sm font-medium leading-6 text-gray-900"><span className="font-medium text-red-600 hover:underline">*</span>Profile Type</h3>
          <ul className="items-center w-full text-sm font-medium text-gray-900 bg-white border border-gray-200 rounded-lg sm:flex">
              <li className="w-full border-b border-gray-200 sm:border-b-0 sm:border-r">
                  <div className="flex items-center ps-3">
                      <input
                        checked={formData.is_public}
                        id="public-radio"
                        type="radio"
                        name="is_public"
                        value="true"
                        onChange={handleChange}
                        className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500 focus:ring-2"
                      />
                      <label htmlFor="public-radio" className="w-full py-3 ms-2 text-sm font-medium text-gray-900">Public</label>
                  </div>
              </li>
              <li className="w-full">
                  <div className="flex items-center ps-3">
                      <input
                        checked={!formData.is_public}
                        id="private-radio"
                        type="radio"
                        name="is_public"
                        value="false"
                        onChange={handleChange}
                        className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500 focus:ring-2"
                      />
                      <label htmlFor="private-radio" className="w-full py-3 ms-2 text-sm font-medium text-gray-900">Private</label>
                  </div>
              </li>
          </ul>
        </div>

        <div>
          <div className="flex items-center space-x-6">
            <ImageProfilInput onImageChange={handleImageChange} />
          </div>
        </div>

        <div>
          <label
            htmlFor="aboutMe"
            className="block mb-2 text-sm font-medium text-gray-900"
          >
            About me
          </label>
          <textarea
            id="aboutMe"
            name="aboutMe"
            rows={4}
            className="block p-2.5 w-full text-sm text-gray-900 bg-gray-50 rounded-lg border border-gray-300 focus:ring-blue-500 focus:border-blue-500"
            value={formData.aboutMe}
            onChange={handleChange}
          />
        </div>

        <div>
          <div className="flex items-center justify-between">
            <label
              htmlFor="password"
              className="block text-sm font-medium leading-6 text-gray-900"
            >
              <span className="font-medium text-red-600 hover:underline">*</span>
              Password
            </label>
          </div>
          <div className="mt-2">
            <input
              id="password"
              name="password"
              type="password"
              value={formData.password}
              onChange={handleChange}
              required
              className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6"
            />
          </div>
        </div>

        <div>
          <div className="flex items-center justify-between">
            <label
              htmlFor="confirmationPassword"
              className="block text-sm font-medium leading-6 text-gray-900"
            >
              <span className="font-medium text-red-600 hover:underline">*</span>
              Confirm Password
            </label>
          </div>
          <div className="mt-2">
            <input
              id="confirmationPassword"
              name="confirmationPassword"
              type="password"
              value={formData.confirmationPassword}
              onChange={handleChange}
              required
              className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6"
            />
          </div>
        </div>

        <div>
          <p
            id="helper-text-explanation"
            className="mt-2 text-sm text-gray-500"
          >
            <span className="font-medium text-red-600 hover:underline">*</span>{" "}
            Ces champs sont obligatoires.
          </p>
        </div>

        <div>
          <button
            type="submit"
            className="flex w-full justify-center rounded-md bg-indigo-600 px-3 py-1.5 text-sm font-semibold leading-6 text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
          >
            Register
          </button>
        </div>
      </form>

      <p className="mt-6 text-center text-sm text-gray-500">
        Already a member ?
        <a
          href="/login"
          className="font-semibold leading-6 text-indigo-600 hover:text-indigo-500 ml-2"
        >
          Log in !
        </a>
      </p>
    </div>
  );
}