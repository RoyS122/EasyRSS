export const notifications = [
    {
        uuid: '7ace7bc4-2146-4cbc-a770-99a745380acc',
        type: 'following_request',
        user_send_uuid: '119adb6d-06d6-4c0e-b6b5-2889ea4f6e05',
        group_send_uuid: null,
        is_read: false,
        created_at: '2024-05-03 10:00:00',
        related_id: ''
    },
    {
        uuid: '644d5812-6f8a-411e-8acc-33733b0974e4',
        type: 'group_invitation',
        user_send_uuid: '068bbef2-c1c8-4250-9141-09824f1e3284',
        group_send_uuid: 'c18d6383-3878-49e7-9b9d-c95d3644fc28',
        is_read: true,
        created_at: '2024-05-03 12:10:00',
        related_id: ''
    },
    {
        uuid: '05855708-fec3-4422-a965-6de6c060c13e',
        type: 'group_join_request',
        user_send_uuid: '3dda899d-d5ca-4f40-b52c-9e82e8d5509c',
        group_send_uuid: 'c18d6383-3878-49e7-9b9d-c95d3644fc28',
        is_read: false,
        created_at: '2024-05-02 09:15:00',
        related_id: ''
    },
    {
        uuid: '103c19dc-c704-4b54-852c-f722e30193c3',
        type: 'group_event',
        user_send_uuid: null,
        group_send_uuid: 'cae1027d-e58b-4e26-a9c9-908041d3053e',
        is_read: true,
        created_at: '2024-05-01 16:45:00',
        related_id: ''
    },
    {
        uuid: '671a9dbb-a99b-4e8f-a6c8-d6a5cf0ffedf',
        type: 'group_chat',
        user_send_uuid: null,
        group_send_uuid: 'e6699762-b9bf-4ef6-8422-5a2c2c62a60a',
        is_read: false,
        created_at: '2024-01-05 11:20:00',
        related_id: ''
    },
    {
        uuid: 'bdd50ef4-2406-4320-baf2-33eed81fbf8c',
        type: 'user_chat',
        user_send_uuid: '499b79b1-b690-401c-be18-c4d3c8c7a88e',
        group_send_uuid: null,
        is_read: true,
        created_at: '2024-02-05 08:10:00',
        related_id: ''
    },
    {
        uuid: '07977449-2227-4e66-9e64-b15255657212',
        type: 'new_group_post',
        user_send_uuid: 'cd991c9d-9a9d-4a2d-9e8d-01f16e7a2b7f',
        group_send_uuid: 'cae1027d-e58b-4e26-a9c9-908041d3053e',
        is_read: false,
        created_at: '2024-05-03 11:45:00',
        related_id: ''
    },
    {
        uuid: '709d3f11-3b26-468f-bbc0-364053374548',
        type: 'new_user_post',
        user_send_uuid: '119adb6d-06d6-4c0e-b6b5-2889ea4f6e05',
        group_send_uuid: null,
        is_read: true,
        created_at: '2024-05-02 16:30:00',
        related_id: ''
    }
];
