export const groupPosts = [
    
    {
        uuid: "7050d5c0-f615-4362-a306-4f8ba93b8e12",
        user_uuid: "cd991c9d-9a9d-4a2d-9e8d-01f16e7a2b7f",
        content: "Hey les amis ! Quelqu'un a des recommandations de films ?",
        date: "2024-04-22",
        type: "group",
        comments: [],
    },
    {
        uuid: "364f8a58-6156-42f8-b2ce-4049f4bf2d4c",
        user_uuid: "119adb6d-06d6-4c0e-b6b5-2889ea4f6e05",
        content: "Salut tout le monde ! Comment ça va aujourd'hui ? 😊",
        imageUrl: "https://picsum.photos/500",
        date: "2024-04-20",
        type: "group",
        comments: [
            {
                uuid: "3e9ce12a-efb0-40f6-bfc2-489a3fe996e4",
                user_uuid: "108fbad9-59a1-40f8-bb40-94ffe7cc3cbd",
                content: "Hey ! Super bien, merci ! Et toi ?",
            },
            {
                uuid: "a6b4bb28-69bb-4a1f-a927-046b4ec4f754",
                user_uuid: "cd991c9d-9a9d-4a2d-9e8d-01f16e7a2b7f",
                content: "Bonjour à tous ! Quelqu'un a des projets pour ce week-end ?",
            },
        ],
    },
    {
        uuid: "1b465ce3-e91c-4811-98aa-df01d6fc4377",
        user_uuid: "cd991c9d-9a9d-4a2d-9e8d-01f16e7a2b7f",
        content:
            "Salut tout le monde ! J'ai trouvé une super recette de cuisine que je veux partager avec vous. Quelqu'un est intéressé ? 😋",
        date: "2024-04-23",
        type: "group",
        comments: [
            {
                uuid: "5aac5cef-ce69-445e-8e22-4f24a32be3f9",
                user_uuid: "cd991c9d-9a9d-4a2d-9e8d-01f16e7a2b7f",
                content: "Ça a l'air délicieux ! Oui, partage-la s'il te plaît !",
            },
        ],
    }
];
