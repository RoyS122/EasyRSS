export const followRequest = [
    {
        user_uuid: '108fbad9-59a1-40f8-bb40-94ffe7cc3cbd',
        followed_by: '068bbef2-c1c8-4250-9141-09824f1e3284',
        is_accepted: false,
    },
    {
        uuid: '068bbef2-c1c8-4250-9141-09824f1e3284',
        followed_by: '119adb6d-06d6-4c0e-b6b5-2889ea4f6e05',
        is_accepted: false,
    },
    {
        uuid: 'cd991c9d-9a9d-4a2d-9e8d-01f16e7a2b7f',
        followed_by: '499b79b1-b690-401c-be18-c4d3c8c7a88e',
        is_accepted: false,
    }
]

export const groupRequest = [
    {
        user_uuid: 'cd991c9d-9a9d-4a2d-9e8d-01f16e7a2b7f',
        group_uuid: '39621ff1-a60c-46fc-b173-db69e96c7b51',
        status: 'request',
    },
    {
        user_uuid: '068bbef2-c1c8-4250-9141-09824f1e3284',
        group_uuid: 'c8c87779-5006-4fea-95e9-9857f44cef60',
        status: 'invite',
    }
    ,
    {
        user_uuid: '068bbef2-c1c8-4250-9141-09824f1e3284',
        group_uuid: 'c8c87779-5006-4fea-95e9-9857f44cef60',
        status: 'accept',
    }
]