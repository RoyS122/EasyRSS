export const groupEvent = [
    {
        uuid: "3e9ce12a-efb0-40f6-bfc2-489a3fe996e4",
        title: "Soirée jeux de société",
        description: "Venez nombreux pour une soirée jeux de société !",
        date_start: "2024-04-21",
        date_end: "2024-04-21",
        users_join : [
            {
                user_id: "499b79b1-b690-401c-be18-c4d3c8c7a88e",
                status: "accepted",
            },
            {
                user_id: "068bbef2-c1c8-4250-9141-09824f1e3284",
                status: "pending",
            }
        ]
    },
    {
        uuid: "b09b15b5-54e1-4147-8890-727c5fe3d319",
        title: "Randonnée en montagne",
        description: "Randonnée en montagne pour les amateurs de nature et de grands espaces.",
        date_start: "2024-04-20",
        date_end: "2024-04-23",
        users_join : [
            {
                user_id: "cd991c9d-9a9d-4a2d-9e8d-01f16e7a2b7f",
                status: "accepted",
            },
            {
                user_id: "108fbad9-59a1-40f8-bb40-94ffe7cc3cbd",
                status: "pending",
            },
            {
                user_id: "3dda899d-d5ca-4f40-b52c-9e82e8d5509c",
                status: "decline",
            }
        ]
    },
    {
        uuid: "9b9381c7-8067-4c39-a727-000578c1a36a",
        title: "Soirée cinéma",
        description: "Venez regarder des films entre amis !",
        date_start: "2024-04-23",
        date_end: "2024-04-23",
        users_join : [
            {
                user_id: "119adb6d-06d6-4c0e-b6b5-2889ea4f6e05",
                status: "pending",
            }
        ]
    }
]