export const chatMessage = [
    {
        user_uuid: "499b79b1-b690-401c-be18-c4d3c8c7a88e",
        chat_message: [
            {
                message: "Bonjour ! As-tu vu le dernier film Marvel ?",
                timestamp: "2022-08-01T12:00:00.000Z",
                sender_is_user: true
            },
            {
                message: "Salut ! Oui, je l'ai vu. C'était incroyable !",
                timestamp: "2022-08-01T12:01:00.000Z",
                sender_is_user: false
            },
            {
                message: "Génial ! Quel était ton moment préféré ?",
                timestamp: "2022-08-01T12:02:00.000Z",
                sender_is_user: true
            },
            {
                message: "Sans spoilers : la scène finale était épique !",
                timestamp: "2022-08-01T12:03:00.000Z",
                sender_is_user: false
            }
        ]
    },
    {
        user_uuid: "119adb6d-06d6-4c0e-b6b5-2889ea4f6e05",
        chat_message: [
            {
                message: "Salut ! Comment s'est passée ta journée ?",
                timestamp: "2022-08-01T12:00:00.000Z",
                sender_is_user: true
            },
            {
                message: "Hey ! Plutôt bien, merci. Et toi ?",
                timestamp: "2022-08-01T12:01:00.000Z",
                sender_is_user: false
            },
            {
                message: "Rien de spécial. Je me détends après le travail.",
                timestamp: "2022-08-01T12:02:00.000Z",
                sender_is_user: true
            },
            {
                message: "C'est important de se reposer. Prends soin de toi !",
                timestamp: "2022-08-01T12:03:00.000Z",
                sender_is_user: false
            }
        ]
    },
    {
        user_uuid: "068bbef2-c1c8-4250-9141-09824f1e3284",
        chat_message: [
            {
                message: "Salut ! As-tu entendu parler de la nouvelle série sur Netflix ?",
                timestamp: "2022-08-01T12:00:00.000Z",
                sender_is_user: true
            },
            {
                message: "Salut ! Oui, j'ai vu la bande-annonce. Ça a l'air génial !",
                timestamp: "2022-08-01T12:01:00.000Z",
                sender_is_user: false
            },
            {
                message: "Je suis impatient de la regarder ce week-end !",
                timestamp: "2022-08-01T12:02:00.000Z",
                sender_is_user: true
            },
            {
                message: "Tu vas adorer ! C'est captivant dès le premier épisode.",
                timestamp: "2022-08-01T12:03:00.000Z",
                sender_is_user: false
            }
        ]
    },
    {
        user_uuid: "cd991c9d-9a9d-4a2d-9e8d-01f16e7a2b7f",
        chat_message: [
            {
                message: "Salut ! Comment se passe ta journée jusqu'à présent ?",
                timestamp: "2022-08-01T12:00:00.000Z",
                sender_is_user: true
            },
            {
                message: "Hey ! C'est plutôt calme. J'essaie de terminer un projet.",
                timestamp: "2022-08-01T12:01:00.000Z",
                sender_is_user: false
            },
            {
                message: "Bonne chance ! Tu peux le faire !",
                timestamp: "2022-08-01T12:02:00.000Z",
                sender_is_user: true
            },
            {
                message: "Merci ! J'espère le finir avant ce soir.",
                timestamp: "2022-08-01T12:03:00.000Z",
                sender_is_user: false
            }
        ]
    },
    {
        user_uuid: "108fbad9-59a1-40f8-bb40-94ffe7cc3cbd",
        chat_message: [
            {
                message: "Salut ! As-tu des plans pour ce week-end ?",
                timestamp: "2022-08-01T12:00:00.000Z",
                sender_is_user: true
            },
            {
                message: "Salut ! Pas vraiment, je pensais juste me détendre à la maison.",
                timestamp: "2022-08-01T12:01:00.000Z",
                sender_is_user: false
            },
            {
                message: "Ça semble être un bon plan. Parfois, c'est tout ce dont on a besoin.",
                timestamp: "2022-08-01T12:02:00.000Z",
                sender_is_user: true
            },
            {
                message: "Exactement ! Rien de mieux que de se détendre.",
                timestamp: "2022-08-01T12:03:00.000Z",
                sender_is_user: false
            }
        ]
    },
    {
        user_uuid: "3dda899d-d5ca-4f40-b52c-9e82e8d5509c",
        chat_message: [
            {
                message: "Salut ! Avez-vous des projets passionnants pour cette semaine ?",
                timestamp: "2022-08-01T12:00:00.000Z",
                sender_is_user: true
            },
            {
                message: "Salut ! Oui, je vais à une exposition d'art demain.",
                timestamp: "2022-08-01T12:01:00.000Z",
                sender_is_user: false
            },
            {
                message: "Ça a l'air super ! Quel genre d'art y aura-t-il ?",
                timestamp: "2022-08-01T12:02:00.000Z",
                sender_is_user: true
            },
            {
                message: "C'est une exposition de peinture contemporaine. J'ai hâte !",
                timestamp: "2022-08-01T12:03:00.000Z",
                sender_is_user: false
            }
        ]
    }
]

export const chatGroupMessage = [
    {
        group_uuid: "0c2c9a06-1964-498a-827e-108166ceaef8",
        chat_message: [
            {
                message: "Message 1",
                timestamp: "2022-08-01T12:03:00.000Z",
                sender_is_user: false,
                user_uuid: "119adb6d-06d6-4c0e-b6b5-2889ea4f6e05",
            },
            {
                message: "Message 2",
                timestamp: "2022-08-01T12:03:00.000Z",
                sender_is_user: true,
                user_uuid: "",
            },
            {
                message: "Message 3",
                timestamp: "2022-08-01T12:03:00.000Z",
                sender_is_user: false,
                user_uuid: "cd991c9d-9a9d-4a2d-9e8d-01f16e7a2b7f",
            },
            {
                message: "Message 4",
                timestamp: "2022-08-01T12:03:00.000Z",
                sender_is_user: false,
                user_uuid: "068bbef2-c1c8-4250-9141-09824f1e3284",
            },
            {
                message: "Message 5",
                timestamp: "2022-08-01T12:03:00.000Z",
                sender_is_user: false,
                user_uuid: "108fbad9-59a1-40f8-bb40-94ffe7cc3cbd",
            }
        ]
    }
]