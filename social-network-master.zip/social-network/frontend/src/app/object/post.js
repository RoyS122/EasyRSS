export const posts = [
  {
    uuid: "f6bd9ca6-c721-41c4-b38b-b4b9374aa9b3",
    user_uuid: "499b79b1-b690-401c-be18-c4d3c8c7a88e",
    content: "Hello there!",
    imageUrl: "https://picsum.photos/500",
    date: "2024-04-20",
    type: "public",
    comments: [
      {
        uuid: "43273798-4a64-4c36-ab8c-f38326d0a3c9",
        user_uuid: "108fbad9-59a1-40f8-bb40-94ffe7cc3cbd",
        content: "Hello there !!!!!",
      },
      {
        uuid: "2e648a76-76a1-4fd4-8250-cc44b2c3c5cd",
        user_uuid: "cd991c9d-9a9d-4a2d-9e8d-01f16e7a2b7f",
        content: "Mon beau commentaire",
      },
    ],
  },
  {
    uuid: "4c7a1bd1-2f41-4415-b506-c0a5840cddfb",
    user_uuid: "cd991c9d-9a9d-4a2d-9e8d-01f16e7a2b7f",
    content:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Consequuntur unde aperiam ab possimus error in dolorum quod nobis velit. Deserunt quae aperiam exercitationem debitis iure autem officia ab modi ratione.Amet, rerum placeat sed illum animi temporibus, architecto vero modi earum repellat adipisci omnis esse! Perspiciatis alias sit aspernatur quidem? Porro soluta earum asperiores non optio quia sed animi corporis! Iusto odit facere distinctio fugit quam totam odio asperiores laudantium necessitatibus adipisci obcaecati hic consequuntur repellat, magnam explicabo ratione aliquid optio eligendi deserunt nesciunt suscipit! Eligendi voluptates autem pariatur beatae!",
    date: "2024-04-21",
    type: "private",
    comments: [
      {
        uuid: "b0cdcb54-3073-4b12-b465-10e423eec6ef",
        user_uuid: "119adb6d-06d6-4c0e-b6b5-2889ea4f6e05",
        content: "Lorem ipsum dolor sit amet.",
      },
    ],
  },
  {
    uuid: "697ae6a7-908c-4d2a-9994-01fe479c23f5",
    user_uuid: "108fbad9-59a1-40f8-bb40-94ffe7cc3cbd",
    content: "Hello there!",
    date: "2024-04-22",
    type: "almost private",
    comments: [],
  },
  {
    uuid: "acf9c4e5-2196-41d7-8179-f69e2a1a74ca",
    user_uuid: "3dda899d-d5ca-4f40-b52c-9e82e8d5509c",
    content:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Consequuntur unde aperiam ab possimus error in dolorum quod nobis velit. Deserunt quae aperiam exercitationem debitis iure autem officia ab modi ratione.Amet, rerum placeat sed illum animi temporibus, architecto vero modi earum repellat adipisci omnis esse! Perspiciatis alias sit aspernatur quidem? Porro soluta earum asperiores non optio quia sed animi corporis! Iusto odit facere distinctio fugit quam totam odio asperiores laudantium necessitatibus adipisci obcaecati hic consequuntur repellat, magnam explicabo ratione aliquid optio eligendi deserunt nesciunt suscipit! Eligendi voluptates autem pariatur beatae!",
    date: "2024-04-23",
    type: "private",
    comments: [
      {
        uuid: "4e3577a8-7f12-4b8a-8d3d-5001b22bd66f",
        user_uuid: "cd991c9d-9a9d-4a2d-9e8d-01f16e7a2b7f",
        content: "Lorem ipsum dolor sit amet.",
      },
    ],
  },
  {
    uuid: "0bcf2d99-568f-4ba5-a0dc-cf0371269ab2",
    user_uuid: "068bbef2-c1c8-4250-9141-09824f1e3284",
    content:
      "Salut tout le monde ! C'est génial d'être ici et de partager nos idées. J'espère que vous passez tous une excellente journée ! N'oubliez pas de sourire :)",
    imageUrl: "https://picsum.photos/500",
    date: "2024-04-24",
    type: "public",
    comments: [
      {
        uuid: "795e0880-b57b-48da-9727-974b7fdfadc4",
        user_uuid: "119adb6d-06d6-4c0e-b6b5-2889ea4f6e05",
        content: "Salut tout le monde ! Merci pour le partage ! :)",
      },
      {
        uuid: "45aef388-ed08-4ed3-839a-02b6151ba0f9",
        user_uuid: "3dda899d-d5ca-4f40-b52c-9e82e8d5509c",
        content: "C'est un contenu vraiment intéressant ! J'adore !",
      },
      {
        uuid: "a2a70cb6-be6f-4214-9f27-2c93b38b534b",
        user_uuid: "108fbad9-59a1-40f8-bb40-94ffe7cc3cbd",
        content:
          "Je suis d'accord avec toi, c'est vraiment inspirant ! Merci de l'avoir partagé.",
      },
    ],
  },
];
