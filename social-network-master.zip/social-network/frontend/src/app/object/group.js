export const groups = [
    {
      uuid: "c8c87779-5006-4fea-95e9-9857f44cef60",
      name: "Fans de Science-Fiction",
      photoUrl: "https://www.shutterstock.com/image-illustration/final-eclipse-3d-illustration-science-260nw-1624177297.jpg",
      description: "Bienvenue dans le groupe des fans de science-fiction ! Nous partageons ici nos passions pour les univers extraordinaires, les technologies futuristes et les aventures intergalactiques.",
      creationDate: "2022-08-01T12:00:00.000Z",
      createdByUserUuid: "cd991c9d-9a9d-4a2d-9e8d-01f16e7a2b7f"
    },
    {
      uuid: "e6699762-b9bf-4ef6-8422-5a2c2c62a60a",
      name: "Photographes en Herbe",
      photoUrl: "https://media.sproutsocial.com/uploads/2022/06/profile-picture.jpeg",
      description: "Bienvenue dans notre groupe dédié à la photographie ! Que vous soyez un amateur passionné ou un professionnel chevronné, vous êtes au bon endroit pour partager vos clichés, recevoir des conseils et découvrir de nouvelles perspectives.",
      creationDate: "2023-08-01T12:00:00.000Z",
      createdByUserUuid: "108fbad9-59a1-40f8-bb40-94ffe7cc3cbd"
    },
    {
      uuid: "0c2c9a06-1964-498a-827e-108166ceaef8",
      name: "Cuisine Créative",
      photoUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTYs-zlwFHcomahLGuCwPLHfCu_XwsYULn4D04fX1T9lA&s",
      description: "Rejoignez-nous pour explorer l'art de la cuisine créative ! De la fusion des saveurs à la présentation artistique, ce groupe est dédié à tous les amateurs de gastronomie qui aiment expérimenter en cuisine.",
      creationDate: "2024-08-01T12:00:00.000Z",
      createdByUserUuid: "108fbad9-59a1-40f8-bb40-94ffe7cc3cbd"
    },
    {
      uuid: "39621ff1-a60c-46fc-b173-db69e96c7b51",
      name: "Amateurs de Musique",
      photoUrl: "https://img.freepik.com/free-photo/creative-treble-clef-sign-isolated-generative-ai_169016-29569.jpg",
      description: "Si vous êtes passionné de musique, ce groupe est fait pour vous ! Partagez vos morceaux préférés, découvrez de nouveaux artistes et discutez de tout ce qui concerne le monde merveilleux de la musique.",
      creationDate: "2022-20-01T12:00:00.000Z",
      createdByUserUuid: "cd991c9d-9a9d-4a2d-9e8d-01f16e7a2b7f"
    },
    {
      uuid: "c18d6383-3878-49e7-9b9d-c95d3644fc28",
      name: "Voyageurs Aventuriers",
      photoUrl: "https://images.pexels.com/photos/346885/pexels-photo-346885.jpeg",
      description: "Bienvenue aux voyageurs intrépides ! Que vous aimiez explorer des destinations exotiques ou découvrir des trésors cachés près de chez vous, ce groupe est l'endroit idéal pour partager vos aventures, vos conseils de voyage et vos histoires inspirantes.",
      creationDate: "2022-08-12T12:00:00.000Z",
      createdByUserUuid: "068bbef2-c1c8-4250-9141-09824f1e3284"
    },
    {
      uuid: "cae1027d-e58b-4e26-a9c9-908041d3053e",
      name: "Lecteurs Passionnés",
      photoUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSHqVOyoR3PlSbW45pw_c3j2OEYA7ko4GjTtuifRupZTA&s",
      description: "Rejoignez notre communauté de lecteurs passionnés ! Que vous aimiez les romans, la poésie, les thrillers ou la science-fiction, ce groupe est un lieu de partage où vous pouvez discuter de vos livres préférés, recommander des lectures et découvrir de nouveaux auteurs.",
      creationDate: "2016-08-01T12:00:00.000Z",
      createdByUserUuid: "3dda899d-d5ca-4f40-b52c-9e82e8d5509c"
    }
  ];
  